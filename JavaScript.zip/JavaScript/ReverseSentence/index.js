function reverseWords(sentence) {
    // Split the sentence into words using whitespace as the separator
    const words = sentence.split(' ');

    // Create an array to store reversed words
    const reversedWords = [];

    // Iterate through the words
    for (const word of words) {
        // Reverse the current word and push it to the reversedWords array
        reversedWords.push(reverseWord(word));
    }

    // Join the reversed words back into a sentence using a space as separator
    const reversedSentence = reversedWords.join(' ');

    return reversedSentence;
}

function reverseWord(word) {
    // Split the word into an array of characters
    const characters = word.split('');

    // Reverse the array of characters and join them back into a word
    const reversedWord = characters.reverse().join('');

    return reversedWord;
}

// Example usage:
const inputSentence = "This is a sunny day";
const reversedSentence = reverseWords(inputSentence);

console.log(reversedSentence); // Output: "sihT si a ynnus yad"
