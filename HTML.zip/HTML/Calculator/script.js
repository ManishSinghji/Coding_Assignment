let display = document.getElementById('display');

function appendToDisplay(value) {
    display.value += value;
}

function clearDisplay() {
    display.value = '';
}

function calculateResult() {
    const expressions = display.value.split(';');
    let result = '';

    for (let i = 0; i < expressions.length; i++) {
        try {
            const exprResult = eval(expressions[i]);
            result += `${expressions[i]} = ${exprResult}; `;
        } catch (error) {
            result += `${expressions[i]} = Error; `;
        }
    }

    display.value = result.trim();
}
